const darkmenu = (prefix) => {
	return `

            COMANDOS:


  *Comandos do Dark:*

➸ *${prefix}loli*
➸ *${prefix}hentai*
➸ *${prefix}dono*
➸ *${prefix}porno*
➸ *${prefix}boanoite*
➸ *${prefix}bomdia*
➸ *${prefix}boatarde*
➸ *${prefix}mia*
➸ *${prefix}mia1*
➸ *${prefix}mia2*
➸ *${prefix}belle*
➸ *${prefix}belle1*
➸ *${prefix}belle2*
➸ *${prefix}belle3*
➸ *${prefix}ayeko*

╔════════════════════
  DUVIDAS? 👇
  WA.me/5581971090625
╚════════════════════`
}

exports.darkmenu = darkmenu








